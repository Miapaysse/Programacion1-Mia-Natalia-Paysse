################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../tp9_ej8/main.c \
../tp9_ej8/puertos.c 

C_DEPS += \
./tp9_ej8/main.d \
./tp9_ej8/puertos.d 

OBJS += \
./tp9_ej8/main.o \
./tp9_ej8/puertos.o 


# Each subdirectory must supply rules for building sources it contributes
tp9_ej8/%.o: ../tp9_ej8/%.c tp9_ej8/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: GCC C Compiler'
	gcc -O0 -g3 -Wall -c -fmessage-length=0 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


clean: clean-tp9_ej8

clean-tp9_ej8:
	-$(RM) ./tp9_ej8/main.d ./tp9_ej8/main.o ./tp9_ej8/puertos.d ./tp9_ej8/puertos.o

.PHONY: clean-tp9_ej8

