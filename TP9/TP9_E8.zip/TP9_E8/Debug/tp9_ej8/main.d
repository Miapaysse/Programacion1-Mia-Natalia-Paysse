tp9_ej8/main.o: ../tp9_ej8/main.c ../tp9_ej8/puertos.h
../tp9_ej8/puertos.h:
