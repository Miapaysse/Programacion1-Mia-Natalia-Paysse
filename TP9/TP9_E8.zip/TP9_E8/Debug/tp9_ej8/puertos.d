tp9_ej8/puertos.o: ../tp9_ej8/puertos.c ../tp9_ej8/puertos.h
../tp9_ej8/puertos.h:
