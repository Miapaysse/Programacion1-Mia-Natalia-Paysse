################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
O_SRCS += \
../tp9_ej8/Debug/main.o \
../tp9_ej8/Debug/puertos.o 


# Each subdirectory must supply rules for building sources it contributes

