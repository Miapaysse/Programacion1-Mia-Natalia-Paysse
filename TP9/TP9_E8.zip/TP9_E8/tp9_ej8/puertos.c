/*
 * puertos.c
 *
 *  Created on: May 16, 2026
 */
#include "puertos.h"

/*******************************************************************************
 * CONSTANTS, MACROS, ENUMERATIONS, STRUCTURES AND TYPEDEFS
 ******************************************************************************/
/*
 * port_word_t:
 * Representa un puerto de 16 bits como un solo número (uint16_t).
 */
typedef struct {

	uint16_t value;

} port_word_t;


/*
 * port_bytes_t:
 * Representa los dos bytes individuales del puerto.
 */
typedef struct {

	uint8_t B;
	uint8_t A;

} port_bytes_t;


/*
 * port_storage_t:
 * Es una unión que permite ver el mismo dato de dos formas:
 * - Como palabra completa de 16 bits
 * - Como dos bytes separados
 * Ambas vistas comparten la misma memoria.
 */
typedef union {

	port_word_t  D;
	port_bytes_t bytes;

} port_storage_t;


/*******************************************************************************
 * STATIC VARIABLES AND CONST VARIABLES WITH FILE LEVEL SCOPE
 ******************************************************************************/
/*
 * port_data:
 * Variable única que contiene el estado del puerto.
 * Inicializa el valor del Puerto D (A Y B) en 0x0000.
 */
static port_storage_t port_data = {.D.value = 0x0000};

/*
 * obtener_puerto_A:
 * Devuelve un puntero al byte A del puerto.
 */
uint8_t* obtener_puerto_A(void){
	return&port_data.bytes.A;
}

/*
 * obtener_puerto_B:
 * Devuelve un puntero al byte B del puerto.
 */
uint8_t* obtener_puerto_B(void){
	return&port_data.bytes.B;
}

/*
 * Obtener_puerto_D:
 * Devuelve un puntero a la palabra completa de 16 bits.
 */
uint16_t* obtener_puerto_D(void) {
	return&port_data.D.value;
}





