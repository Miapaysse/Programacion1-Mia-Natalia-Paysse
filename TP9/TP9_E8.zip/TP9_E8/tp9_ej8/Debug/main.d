main.o: ../main.c ../puertos.h
../puertos.h:
