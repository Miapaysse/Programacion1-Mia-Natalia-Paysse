puertos.o: ../puertos.c ../puertos.h
../puertos.h:
