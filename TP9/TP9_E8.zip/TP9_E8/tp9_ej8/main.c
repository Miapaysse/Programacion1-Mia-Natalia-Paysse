/*
 * main.c
 *
 *  Created on: May 16, 2026
 * 	Ejemplo de uso de las funciones y macros para manipular el puerto de 16 bits y sus bytes.
 */

#include "puertos.h"
int main(void) {

    /* Punteros a los tres puertos */

		uint16_t* puertoD = obtener_puerto_D();
	    uint8_t* puertoA = obtener_puerto_A();
	    uint8_t* puertoB = obtener_puerto_B();

	    printf("Estado inicial D: 0x%04X\n", *puertoD);

	    /* Prender bits */

	    bitSet(*puertoD, 1);
	    bitSet(*puertoD, 3);

	    printf("bitSet(1 y 3):    0x%04X\n", *puertoD);

	    /* Toggle */

	    bitToggle(*puertoD, 3);

	    printf("toggle bit 3:     0x%04X\n", *puertoD);

	    /* Clear */

	    bitClr(*puertoD, 1);

	    printf("clear bit 1:      0x%04X\n", *puertoD);

	    /* Máscaras */

	    maskOn(*puertoD, 0x00F0);

	    printf("maskOn(F0):       0x%04X\n", *puertoD);

	    maskOff(*puertoD, 0x0020);

	    printf("maskOff(20):      0x%04X\n", *puertoD);

	    maskToggle(*puertoD, 0x000F);

	    printf("maskToggle(0F):   0x%04X\n", *puertoD);

	    /* Ver bytes */

	    printf("Puerto A:         0x%02X\n", *puertoA);
	    printf("Puerto B:         0x%02X\n", *puertoB);

    return 0;
}
