#include <stdint.h>
#include <stdio.h>
#include "funciones.h"


int main (void){
    mostrar_leds();
    if (procesar_entrada() == -1){
        return 0;
    }
}

