/*
 * backend.c
 *
 *  Created on: May 17, 2026
 *      Author: progra
 */
#include <stdint.h>
#include <stdio.h>

#include "funciones.h"
#include "puertos.h"

/*******************************************************************************
 * CONSTANTS, MACROS, ENUMERATIONS, STRUCTURES AND TYPEDEFS
 ******************************************************************************/

//PUERTOS
#define PORT_A *obtener_puerto_A()
#define PORT_B *obtener_puerto_B()

typedef struct {
	uint8_t B;
	uint8_t A;
} ports_t;

typedef union {
	ports_t port;
	uint16_t D;
} hardware_t;

/*******************************************************************************
 * STATIC VARIABLES AND CONST VARIABLES WITH FILE LEVEL SCOPE
 ******************************************************************************/
static hardware_t myPorts = {.D = 0x1001};

/*******************************************************************************
 *******************************************************************************
                        GLOBAL FUNCTION DEFINITIONS
 *******************************************************************************
 ******************************************************************************/

uint8_t* obtener_puerto_A(void) { return &myPorts.port.A; }
uint8_t* obtener_puerto_B(void) { return &myPorts.port.B; }
uint16_t* obtener_puerto_D(void) { return &myPorts.D; }

int procesar_entrada(void){
    char caracter; //c ?
    while ((caracter = getchar()) != 'q'){ //\n
        if (caracter == '\n'){
            continue;
        }
        else if (caracter >= '0' && caracter <= '7' ){
            uint8_t led = caracter - '0'; //Cambia los estados del LED indicado
            bitToggle(PORT_A, led);
            mostrar_leds();
        }
        else if (caracter == 't'){
            maskToggle(PORT_A, 0xFFU); //Cambia los estados de todos los LEDs
            mostrar_leds();
        }
        else if (caracter == 'c'){ //Pone todos los LEDs en 0
            maskOff(PORT_A, 0xFFU);
            mostrar_leds();
        }
        else if (caracter == 's'){ //Pone todos los LEDs en 1
            int i;
            for(i = 0; i < 8; i++){
                bitSet(PORT_A,i);
            }
            mostrar_leds();
        }
        else {
            printf("Error, caracter invalido, por favor vuelva a intentar\n");
        }
    }
    return -1;
}

void mostrar_leds(void){
    int i;
    uint8_t mask;
    for(i=7, mask = (1<<7) ; mask != 0; i--){ //mask 0100 0000 i=6
        printf("%d", (PORT_A &mask)>>i);//0
        mask >>= 1;//0100 0000
    }
    printf("\n");
}

