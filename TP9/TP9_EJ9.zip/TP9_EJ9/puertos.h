/*
 * puertos.h
 *
 *  Created on: May 16, 2026
 */

#ifndef PUERTOS_H_
#define PUERTOS_H_

/*******************************************************************************
 * INCLUDE HEADER FILES
 ******************************************************************************/
#include <stdio.h>
#include <stdint.h>

/*******************************************************************************
 * CONSTANTS, MACROS, ENUMERATIONS, STRUCTURES AND TYPEDEFS
 ******************************************************************************/
#define bitSet(port, bit) ((port) |= (1U << (bit)))
/*
 * Pone en 1 el bit indicado.
 * Usa OR con una máscara que tiene un 1 solo en el bit indicado.
 */

#define bitClr(port,bit) ((port) &= ~(1U << (bit)))
/*
 * Pone en 0 el bit indicado.
 * Usa AND con el complemento de la máscara.
 */

#define bitGet(port,bit) (((port) & (1U << (bit))) != 0U)
/*
 * Obtiene el valor del bit indicado (0 o 1).
 * Devuelve true si el bit está encendido.
 */

#define bitToggle(port,bit) ((port)^=(1U << (bit)))
/*
 * Invierte el valor del bit indicado.
 * Usa XOR.
 */

#define maskOn(port, mask)     ((port) |=  (mask))
/*
 * Prende todos los bits puestos en 1 en la máscara.
 * Usa OR
 */

#define maskOff(port, mask)    ((port) &= ~(mask))
/*
 * Apaga todos los bits puestos en 1 en la máscara.
 * Usa AND
 */

#define maskToggle(port, mask) ((port) ^=  (mask))
/*
 * Cambia todos los bits puestos en 1 en la máscara.
 * Usa XOR
 */

/*******************************************************************************
 * FUNCTION PROTOTYPES WITH GLOBAL SCOPE
 ******************************************************************************/
/* Funciones que devuelven punteros a los puertos A, B o D */

uint8_t* obtener_puerto_A(void);

uint8_t* obtener_puerto_B(void);

uint16_t* obtener_puerto_D(void);


#endif /* PUERTOS_H_ */
