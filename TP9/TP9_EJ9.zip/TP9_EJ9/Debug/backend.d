backend.o: ../backend.c ../funciones.h ../puertos.h
../funciones.h:
../puertos.h:
