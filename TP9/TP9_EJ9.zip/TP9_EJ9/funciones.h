/*
 * backend.h
 *
 *  Created on: May 17, 2026
 *      Author: progra
 */

#ifndef BACKEND_H_
#define BACKEND_H_


/*******************************************************************************
 * FUNCTION PROTOTYPES WITH GLOBAL SCOPE
 ******************************************************************************/
void mostrar_leds(void);
int procesar_entrada(void);


#endif /* BACKEND_H_ */
